import { registerBannerHandling } from '../features/banner-handling';
import { visitCountryPage } from '../features/country-page-handling';
import { getTripIdeas, getTripIdeasAsStringArray } from '../features/grid-fetcher';
import Chainable = Cypress.Chainable;

describe('Checks that the Country Page filters work', () => {

    let startTime = Date.now();

    function logTime(message: string) {
        // Remove logging for now
        //const elapsed = Date.now() - startTime;
        //cy.task('log', `Got to ${message} at ${elapsed}ms`);
    }

    /**
     * Run this before every single test
     */
    beforeEach(() => {
        logTime('start');
        registerBannerHandling();

        logTime('before visit');
        cy.visit('/');
        logTime('after visit');
        cy.dismissTravelLocalVercelDevice();
        logTime('after dismissing Vercel device');
        cy.dismissTravelLocalRegionDialogue();
        logTime('after dismissing region dialogue');
        cy.dismissTravelLocalCookieDialogue();
        logTime('after dismissing cookie dialogue');

        visitCountryPage();
        logTime('after visiting the country page');
    });

    function openTheNthFilterMenu(filterNumber: number): Chainable<JQuery<HTMLElement>> {
        return cy
            .get('#sharedTrips .filtersContainer button')
            .eq(filterNumber)
            .click();
    }

    function assertIdeasHaveChanged($initial: JQuery<HTMLElement>): Chainable<JQuery<HTMLElement>> {
        return getTripIdeas().should($final => {
            const initialElements = $initial.toArray();
            const finalElements = $final.toArray();
            expect(initialElements).to.not.deep.eq(finalElements);
        });
    }

    /**
     * H/T to https://stackoverflow.com/a/79151506 for the wait technique
     */
    it('Test the trip experiences filter', () => {
        getTripIdeas().then($initial => {
            logTime('before opening the filter');
            // Opens the experiences filter menu
            openTheNthFilterMenu(0);
            logTime('after opening the filter');

            // Now choose a filter option, so the ideas change
            cy
                .get('#sharedTrips .filtersContainer label[for="experiencesrelax"]')
                .click();
            logTime('after choosing a filter');

            assertIdeasHaveChanged($initial);
        });
    });

    it('Test the trip budget filter (min) using text', () => {
        getTripIdeas().then($initial => {
            // Opens the budget filter menu
            openTheNthFilterMenu(1);

            cy
                .get('#sharedTrips .filtersContainer .budget-filter input[type="number"]')
                .first()
                .clear()
                .type('1500');

            assertIdeasHaveChanged($initial);
        });
    });

    it('Test the trip budget filter (max) using text', () => {
        getTripIdeas().then($initial => {
            // Opens the budget filter menu
            openTheNthFilterMenu(1);

            cy
                .get('#sharedTrips .filtersContainer .budget-filter input[type="number"]')
                .last()
                .clear()
                .type('2500');

            assertIdeasHaveChanged($initial);
        });
    });

    it('Test the trip budget filter using the slider', () => {
        // Opens the budget filter menu
        openTheNthFilterMenu(1);
    });

    it('Test the trip length filter', () => {
        getTripIdeas().then($initial => {
            // Opens the length filter menu
            openTheNthFilterMenu(4);

            cy
                .get('#sharedTrips .filtersContainer label.form-checkbox')
                .first()
                .click();

            assertIdeasHaveChanged($initial);
        });
    });

    it('Test the travel style filter', () => {
        // Opens the travel style filter menu
        openTheNthFilterMenu(5);
    });

    it('Test the trip regions filter', () => {
        // Opens the regions filter menu
        openTheNthFilterMenu(6);
    });

    it('Test the trip accommodation filter', () => {
        // Opens the accommodation filter menu
        openTheNthFilterMenu(7);
    });
});
