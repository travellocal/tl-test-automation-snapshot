export function getTripIdeasAsStringArray(): string[] {
    const titles: string[] = [];
    getTripIdeas().each((i, el) => {
        titles.push(i.find('h3').text());
    });

    return titles;
}

/**
 * Grabs a grid of items (e.g. a set of cards) based on a CSS expression
 */
export function getTripIdeas(): Cypress.Chainable<JQuery<HTMLElement>> {
    return getGridElements(
        '#sharedTrips section .container div:last-child .card-layout div.column'
    );
}

/**
 * General CSS chainable function
 */
export function getGridElements(cssSelector: string): Cypress.Chainable<JQuery<HTMLElement>> {
    return cy
        .get('body')
        .find(cssSelector);
}
