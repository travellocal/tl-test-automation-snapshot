# Test Automation

## Introduction

This is a test of Cypress, to see whether it might be a match for our E2E
requirements for browser-testing the TL app.  Once this test phase is completed,
we will compare the work here with the PHP/Selenium solution here:

https://github.com/travellocal/tl-test-automation

## Instructions

This is a fully-containerised test pack. To do the initial image build:

    ./bin/docker-build.sh

To start the Cypress container in Docker, run:

    ./bin/docker-start.sh

This will drop you straight into a shell, from where you can issue commands.
We don't have an explicit `docker-stop.sh` command, as locally you can just do
Ctrl-D to drop out of the shell, and stop the container.

## Workflow

To run Cypress tests, use the supplied executable:

    cypress run

This presently defaults to the standard browser, which is Electron, but one can
select Firefox using this simple additional command:

    cypress run --browser firefox

(This command is a symlink to `/project/node_modules/cypress/bin/cypress`,
where the package is installed via NPM).

Since the above is the most common command we will use, there is a shortcut
for it:

    /root/run-tests.sh

(At the time of writing there is no simple way to specify a browser in configuration,
[see this issue](https://github.com/cypress-io/cypress/issues/6646), but using
the console is fine for now).

Screenshots
---

Screenshots by default snapshot the whole page, rather than the viewport. Cypress
does not do so well stitching the page together, partly because there are
fixed-position items (like the cookie banner) that it renders for every screenful
of the shot.

But one can adjust the screenshot behaviour by specifying that only the viewport
needs to be captured:

    cy.screenshot('home', { capture: 'viewport' });

Test filtering
---

If you want to just run one spec file, you can do this:

    cypress run --spec cypress/e2e/home-spec.cy.ts

File wildcards are permitted too.

During development, if you want to isolate a single test to run independently,
you need to do it in code. Change your `it()` to `it.only()` and it will skip
all the others:

https://www.browserstack.com/guide/cypress-skip-test

Automation
---

At the time of writing, all pushes to this repo will run the tests against Staging:

https://github.com/travellocal/tl-test-automation/actions
