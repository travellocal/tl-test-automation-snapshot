#!/bin/sh
#
# See https://github.com/cypress-io/cypress/pull/17309/files for the
# Firefox-specific screen width. This can be thought of as a maximum screen
# size, but any viewport widths less than this will take precedence, and any
# viewport widths more than this will be ignored. So this can be set to a
# large number, and then the viewport width set to what is desired inside
# the test pack.

MOZ_HEADLESS_WIDTH=1440 cypress run --browser firefox
