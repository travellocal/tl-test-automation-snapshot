Debugging
---

If you want to dig into specific DOM text/values/etc. then use something
like this template:

    cy.get('body').then((body: JQuery<HTMLBodyElement>) => {
        const headings: JQuery<HTMLElement> = body.find(
            '#modal h1'
        );
        cy.task('log', 'Looking for heading tags');
        if (headings && headings.length > 0) {
            cy.task(
                'log',
                'Heading: ' + headings[0].getHTML()
            );
        }
    });
