/**
 * Example test
 *
 * @todo Move the screenshot code to a feature file
 */

import { registerBannerHandling } from '../features/banner-handling';

describe('Checks the home page', () => {
    beforeEach(() => {
        registerBannerHandling();

        cy.visit('/');
        cy.dismissTravelLocalVercelDevice();
        cy.dismissTravelLocalRegionDialogue();
        cy.dismissTravelLocalCookieDialogue();
    });

    it('Ensures the home page has the expected top title', () => {

        cy.screenshot('home', { capture: 'viewport' });
        cy
            .get('main h1')
            .should('have.text', 'Global travel, local experts')
    });
});
