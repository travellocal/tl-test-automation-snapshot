declare global {
    namespace Cypress {
        interface Chainable {
            /**
             * Closes the region dialogue box without making a choice
             */
            dismissTravelLocalRegionDialogue(): Chainable<JQuery<HTMLElement>>;

            /**
             * Closes the cookie banner with the minimal cookies preference
             */
            dismissTravelLocalCookieDialogue(): void;

            /**
             * Uses JS to hide the Vercel debugging control
             */
            dismissTravelLocalVercelDevice(): void;
        }
    }
}

export function registerBannerHandling() {

    Cypress.Commands.add('dismissTravelLocalRegionDialogue', () => {
        return cy
            .get('#modal header button[aria-label="Close Dialog"]')
            .click();
    });

    Cypress.Commands.add('dismissTravelLocalCookieDialogue', () => {

        // This device tries to find/dismiss a cookie dialogue box
        cy
            .get('body')
            .then((body: JQuery<HTMLBodyElement>) => {
                if (body.text().includes('Use necessary cookies only')) {
                    cy
                        .get('button[aria-label="Deny all cookies"]')
                        .click()
                        .get('dialog[aria-label="Cookie banner"]')
                        .should('not.exist');
                }
            });
    });

    Cypress.Commands.add('dismissTravelLocalVercelDevice', () => {
        cy
            .window()
            .then((win) => {
                win.eval(
                    "const elements = document.getElementsByTagName('vercel-live-feedback');\n" +
                    "if (elements.length) {\n" +
                    "    elements[0].style.display = 'none';\n" +
                    "}"
                );
            });
    });
}
