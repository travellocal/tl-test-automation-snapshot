import { getTripIdeas } from './grid-fetcher';

declare global {
    namespace Cypress {
        interface Chainable {
            /**
             * Closes the region dialogue box without making a choice
             */
            visitCountryPage(): void;
        }
    }
}

    export function visitCountryPage(locale: string = 'en'): void {
        // Visit a country-specific URL
        cy.visit(`/${locale}/destinations/jordan`);

        // Check the heading is as expected
        cy
            .get('#modal h1')
            .should('have.text', 'Visit Jordan');

        // Scroll to the area of interest
        cy.window().then((win: Cypress.AUTWindow) => {
            win.eval(
                "// This looks pretty x-browser, see https://caniuse.com/scrollintoview\n" +
                "document.getElementById('sharedTrips').scrollIntoView();\n" +
                "// Go up a bit, otherwise the filters will be hiding under the page header\n" +
                "window.scrollBy(0, -150);"
            )
        });

        // Wait for the suggestions to populate
        getTripIdeas().should('have.length', 8);
    }

/**
 * FIXME I think I should make use of this, I think this is how to use Chainables
 * FIXME without having to explicitly return the Chainable value.
 */
export function registerCountryPageHandling() {

    Cypress.Commands.add('visitCountryPage', (locale: string = 'en') => {
        return visitCountryPage(locale);
    });

}
