/**
 * @todo Make a note to review this, can't recall what it is for
 */
Cypress.on('uncaught:exception', (err, runnable) => {
    // returning false here prevents Cypress from failing the test
    return false;
});
