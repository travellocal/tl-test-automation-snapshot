import { defineConfig } from 'cypress';
import PluginEvents = Cypress.PluginEvents;
import PluginConfigOptions = Cypress.PluginConfigOptions;
import { readdirSync, rmSync } from 'fs';
import path from 'path';
import Dirent from 'fs';

export default defineConfig({
    e2e: {
        baseUrl: 'https://staging1.travellocal.com',

        // I've stopped deletion of images, as it wipes the
        // whole folder, including the Git dummy file
        "trashAssetsBeforeRuns": false,

        // And here is a nicer delete, which just deletes files
        setupNodeEvents(on: PluginEvents, config: PluginConfigOptions) {
            on('before:run', () => {
                const files: Dirent.Dirent[] = readdirSync(
                    '/project/cypress/screenshots',
                    { withFileTypes: true, recursive: true }
                );
                let regex = /[.]png$/;
                files
                    .filter((f: Dirent.Dirent) => regex.test(f.name))
                    .map((f: Dirent.Dirent) => rmSync(path.join(f.parentPath, f.name)));
            });

            // A logger that actually works mid-test
            on('task', {
                log(message: string) {
                    console.log(message);
                    return null;
                },
            });
        },
    },

    // The operating screen width (the "viewport") cannot be wider than the
    // size of the browser window, which in the current version of Cypress is
    // 1280 by default. However, this can be modified per browser e.g. using
    // MOZ_HEADLESS_WIDTH for Firefox.
    viewportWidth: 1440,

    defaultCommandTimeout: 20 * 1000,
});
