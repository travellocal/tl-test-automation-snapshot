# To-do items

Here are a few things that might be interesting to achieve if we decide
to pick Cypress (TS) over Selenium (PHP).

* Separate container(s) for the browsers
